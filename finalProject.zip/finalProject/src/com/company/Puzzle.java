package com.company;
import java.util.Scanner;
import java.security.SecureRandom;

public class Puzzle {



}
