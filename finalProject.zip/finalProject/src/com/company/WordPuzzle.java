package com.company;
import java.util.Random;
import java.util.Scanner;

public class WordPuzzle {
    public static void main(String[] args){
        displayBoard();
        wordsToFind();
        randomLetter();
    }
    public static int numRows() {
        int row;
        do {
            Scanner keyboard = new Scanner(System.in);
            System.out.printf("Enter the number of rows that you would like in the word search that are between 2 and 15:");
            row = keyboard.nextInt();
            if (row < 2 || row > 15) {
                System.out.printf("The number you entered is not within our parameters(2-15). Please enter another number");
            }
        } while (row < 2 || row > 15);
        return row;
    }

    public static int numColumns() {
        int col;
        do {
            Scanner keyboard = new Scanner(System.in);
            System.out.printf("Enter the number of columns that you would like in the word search that are between 2 and 15:");
            col = keyboard.nextInt();
            if (col < 2 || col > 15) {
                System.out.printf("The number you entered is not within our parameters(2-15). Please enter another number");
            }
        } while (col < 2 || col > 15);
        return col;
    }

    public static char[][] displayBoard() {
        String gameBoard = "";
        char[][] table = new char[numRows()][numColumns()];
        for (int x = 0; x < numRows(); x++) {
            for (int y = 0; y < numColumns(); y++) {
                gameBoard += table[x][y] + "   ";
            }
            gameBoard += "\n";
        }
    return displayBoard();
    }



    public static char[][] randomLetter() {


        Random random = new Random();
        char letter;
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for (int x = 0; x < numRows(); x++) {
            for (int y = 0; y < numColumns(); y++) {
                letter = alphabet.charAt(random.nextInt(alphabet.length()));
                displayBoard();
                numRows();
                numColumns();
            }
            return displayBoard();
        }
        System.out.printf("%s%c", displayBoard(), randomLetter());
        return new char[0][];
    }






                public static String[] wordsToFind() {
                    Scanner keyboard = new Scanner(System.in);
                    String[] words = new String[numRows()];
                    for (int i = 0; numColumns() > i; i++) {
                        do {
                            System.out.printf("Enter a word between &d and 2 letters", numRows());
                            if (2 > words[i].length()) {
                                System.out.printf("The word you entered has to be more than 2 letters.");
                            }
                            if (15 < words[i].length()) {
                                System.out.printf("The word you entered has to be less than 15 letters.");
                            }
                        } while (15 < words[i].length() || 2 > words[i].length());
                    }
                    return words;
                }


      /*public String makeGame(){
       for (int i = 0; i < numRows(); i++) {
          for (i = 0; i < numColumns(); i++) ;

                        }

                    }




                }
                public void randomNumbers(){
                    SecureRandom rng = new SecureRandom();
                    int num = rng.nextInt(numColumns()) + 1;}*/


       /*for (int i = 0; i < numRows(); i++) {
           randomLetter() = randomNumbers(numColumns() - words[i].length() + 1);
           for (i = 0; i < numColumns; i++) {
            if (i < (words[i].length() + randomNumbers()) && i >= randomNumbers())
               randomLetter()[numRows()][numColumns()] = words[i].charAt(i - randomNumbers());*/



                    }



